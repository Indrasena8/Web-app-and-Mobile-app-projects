var x=document.getElementById("id1");
function abc(obj)
{
    var pushed=obj.innerHTML;
    if(pushed=="=")
        {
            x.innerHTML=eval(x.innerHTML);
        }
    else if(pushed=="AC")
        {
            x.innerHTML="0";
        }
    else
        {
            if(x.innerHTML=="0")
                {
                    x.innerHTML=pushed;
                }
            else
                {
                    x.innerHTML=x.innerHTML+pushed;
                }
        }
}
