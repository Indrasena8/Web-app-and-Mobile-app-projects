This application is a multi-app where user login (database) exits.
It contains 4 applications 
1. Calculator
2. Temparature Convertor
3. GPS tracker
4. Currency Convertor
