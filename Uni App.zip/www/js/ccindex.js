function abc()
{
    var x=document.getElementById("t1").value;
    var y=document.getElementById("s1").value;
    if(y=="d")
        {
            document.getElementById("t2").value=x*69.0955;
        }
    if(y=="e")
        {
            document.getElementById("t2").value=x*77.37;
        }
    if(y=="p")
        {
            document.getElementById("t2").value=x*91.13;
        }
    if(y=="j")
        {
            document.getElementById("t2").value=x*0.6219;
        }
    if(y=="c")
        {
            document.getElementById("t2").value=x*51.4812;
        }
    if(y=="s")
        {
            document.getElementById("t2").value=x*91.13;
        }
}