function abc()
{
    var x=document.getElementById("t1").value;
    document.getElementById("t2").value=((x-32)*5)/9;
}
function def()
{
    var y=document.getElementById("t2").value;
    document.getElementById("t1").value=((y*9)/5)+32;
}
function ghi()
{
    document.getElementById("t1").value=clearInterval;
    document.getElementById("t2").value=clearInterval;
}